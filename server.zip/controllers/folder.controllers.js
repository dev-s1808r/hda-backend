const { Folder, File } = require("../models/models");
const { scanFolder } = require("../utils/scanFolder");

const createFolder = async (req, res) => {
  const { folderName, folderLocation, contentType } = req.body;
  try {
    const folder = new Folder({ folderName, folderLocation, contentType });
    await folder.save();
    res.status(201).json(folder);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getFolders = async (req, res) => {
  try {
    const folders = await Folder.find();
    res.status(200).json(folders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const createFolderWithFiles = async (req, res) => {
  console.log("req.body", req.body);
  const { folderName, folderLocation, contentType } = req.body;

  try {
    // Step 1: Save the folder details
    const folder = new Folder({ folderName, folderLocation, contentType });
    await folder.save();

    // Step 2: Scan the folder for files
    const files = scanFolder(folderLocation);

    // Step 3: Save files to the database
    const fileEntries = files.map((file) => ({
      folderId: folder._id,
      fileName: file.fileName,
    }));

    await File.insertMany(fileEntries);

    res.status(201).json({ folder, files: fileEntries });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: err.message });
  }
};

let folder = {
  createFolder,
  getFolders,
  createFolderWithFiles,
};

module.exports = folder;
