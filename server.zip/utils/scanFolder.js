const fs = require("fs");
const path = require("path");

const scanFolder = (folderPath) => {
  if (!fs.existsSync(folderPath)) {
    throw new Error("Folder does not exist");
  }

  const files = fs.readdirSync(folderPath).map((file) => {
    return {
      fileName: file,
      filePath: path.join(folderPath, file),
    };
  });

  return files;
};

module.exports = { scanFolder };
