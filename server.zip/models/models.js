const mongoose = require("mongoose");

const folderSchema = new mongoose.Schema({
  folderName: { type: String, unique: true, required: true },
  folderLocation: { type: String, unique: true, required: true },
  contentType: {
    type: String,
    enum: ["audio", "video", "photos", "documents"],
    required: true,
  },
});

const fileSchema = new mongoose.Schema({
  folderId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Folder",
    required: true,
  },
  fileName: { type: String, unique: true, required: true },
  status: {
    type: String,
    enum: ["draft", "published", "hidden"],
    default: "draft",
  },
});

const Folder = mongoose.model("Folder", folderSchema);
const File = mongoose.model("File", fileSchema);

module.exports = {
  Folder,
  File,
};
