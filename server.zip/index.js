const express = require("express");
const cors = require("cors");
const initiate = require("./config/initiate");
const folder = require("./controllers/folder.controllers");
const file = require("./controllers/files.controller");
const app = express();

app.use(express.json());
app.use(cors());

app.get("/folders", folder.getFolders);
app.post("/add-folder", folder.createFolderWithFiles);
app.get("/files/:id", file.getFiles);

initiate(app);
